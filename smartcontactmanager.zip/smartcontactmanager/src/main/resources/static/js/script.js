function toggleSideBar() {
    
    const sidebar =  document.getElementsByClassName("sidebar")[0];
    const content =  document.getElementsByClassName("content")[0];

    if(window.getComputedStyle(sidebar).display === "none"){
        sidebar.style.display = "block";
        content.style.marginLeft = "18%";
        navbar.style.marginLeft = "0%";
    }
    else{
        sidebar.style.display = "none";
        content.style.marginLeft = "0%";
    }
}