package com.smart.smartcontactmanager.controller;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


import com.smart.smartcontactmanager.dao.UserRepository;
import com.smart.smartcontactmanager.entities.User;
import com.smart.smartcontactmanager.service.EmailService;


import jakarta.servlet.http.HttpSession;

@Controller
public class ForgetController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Autowired
    private EmailService emailService;
    Random random = new Random(100000);

    @RequestMapping("/forgetpassword")
    public String forgetPassword(Model model){
        model.addAttribute("title", "Forgot Password");
        
        return "forget-password";
    }

    @PostMapping("/send-otp")
    public String sendOTP(@RequestParam("email") String email, Model model, HttpSession session){
        
        User user = this.userRepository.getUserByUserName(email);
        if(user == null){
            return "invalid-email-for-forget-password";
        }
        model.addAttribute("title", "Send OTP");

        //generating 6 digits random otp
        int otp = random.nextInt(999999);
        
        System.out.println("OTP: " +otp);

        String subject = "OTP from Smart Contact Manager";
        String otp1 = Integer.toString(otp);
        String message = "OTP is : " +otp1;
        String to = email;

        boolean flag = this.emailService.sendEmail(subject, message, to);
        
        if(flag){
            session.setAttribute("myotp", otp);
            session.setAttribute("email", email);
            return "verify_otp";
        }else{
            return "invalid-email-for-forget-password";
        }
    }

    @PostMapping("/change-password")
    public String changePassword(@RequestParam("otp") int enteredotp, Model model, HttpSession session ){
    
        int myotp = (int)session.getAttribute("myotp"); 
        String email = (String) session.getAttribute("email");
        // String myotp1 = Integer.toString(myotp);
        // String enteredotp1 = Integer.toString(enteredotp);

        if(enteredotp == myotp){
            model.addAttribute("title", "Change Password");
            
            User user =  this.userRepository.getUserByUserName(email);
            System.out.println(user);
            if(user == null){
                //send error message
                return "invalid-email-for-forget-password";
            }else{
                //send change password
                return "change-password"; 
            }   
            
        }else{
            return "verify_otp";
        }
    }

    @PostMapping("/password-validate")
    public String passwordValidate(@RequestParam("password") String password, @RequestParam("confirm-password") String confirmpPassword, Model model, HttpSession session){
        
        if(password.equalsIgnoreCase(confirmpPassword)){
            String email = (String) session.getAttribute("email");
            User user =  this.userRepository.getUserByUserName(email);

            user.setPassword(this.bCryptPasswordEncoder.encode(password));
            this.userRepository.save(user);

            
            return "redirect:/signin?change= password updated successfully";

            // return "password-update-successfull";
        }else{


            return "change-passwordd-error";
        } 
    }

}
