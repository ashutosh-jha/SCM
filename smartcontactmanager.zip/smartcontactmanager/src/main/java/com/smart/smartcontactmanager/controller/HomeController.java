package com.smart.smartcontactmanager.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.smart.smartcontactmanager.dao.UserRepository;
import com.smart.smartcontactmanager.entities.User;
import com.smart.smartcontactmanager.helper.Message;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
public class HomeController {
    
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @RequestMapping("/index")
    public String home(Model model){
        model.addAttribute("title", "Home Page");
        return "index";
    }

    @RequestMapping("/about")
    public String about(Model model){
        model.addAttribute("title", "About Section");
        return "about";
    }

    @RequestMapping("/signup")
    public String signup(Model model, HttpSession session){
        model.addAttribute("title", "Registration - Smart Contact Manager");
        model.addAttribute("user", new User());
        session.removeAttribute("message");
        return "signup";
    }

    @RequestMapping("/signin")
    public String signin(Model model){
        model.addAttribute("title", "Login - Smart Contact Manager");
        return "login";
    }

    //this is handling new registration of users

    @RequestMapping(value = "/do_register", method = RequestMethod.POST)
    public String registerUser(@Valid @ModelAttribute("user") User user, BindingResult result1, @RequestParam(value = "agreement", defaultValue = "false") boolean agreement,  Model model,  HttpSession session){
        
        try {
            
            if(!agreement){
                throw new Exception(" You have not accepeted the terms and conditions!!");
                
            }

            if(result1.hasErrors()){

                model.addAttribute("user", user);
                return "signup";

            }
            user.setRole("ROLE_USER");
            user.setEnabled(true);
            user.setImageUrl("default.png");
            user.setPassword(passwordEncoder.encode(user.getPassword()));

            System.out.println("AGREEMENT: " +agreement);
            System.out.println("USER: " + user);
        
            this.userRepository.save(user);

            model.addAttribute("user", new User());
            return "success";
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("user", user);
            if(!agreement){
                session.setAttribute("message", new Message(" " + e.getMessage(), "alert-danger"));
            }else{
                session.setAttribute("message", new Message("Something went wrong!!! " + e.getMessage(), "alert-danger"));
            }
            return "signup";
        }
    }
}
