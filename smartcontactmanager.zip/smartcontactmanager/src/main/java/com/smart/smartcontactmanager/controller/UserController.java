package com.smart.smartcontactmanager.controller;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.Optional;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.smart.smartcontactmanager.dao.ContactRepository;
import com.smart.smartcontactmanager.dao.UserRepository;
import com.smart.smartcontactmanager.entities.Contact;
import com.smart.smartcontactmanager.entities.User;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;


@Controller
@Transactional
@RequestMapping("/user")
public class UserController {
    
    @Autowired
    private UserRepository userRepository;
    private java.nio.file.Path path;

    @Autowired
    private ContactRepository contactRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @ModelAttribute
    public void addCommonData(Model model, Principal principal){
        String userName= principal.getName();

        User user = userRepository.getUserByUserName(userName);
        model.addAttribute("user", user);

    }

    @RequestMapping("/dashboard")
    public String dashboard(Model model, Principal principal){
        model.addAttribute("title", "User-Home");
        return "user_dashboard";
    }

    // addContact handler
    @GetMapping("/add-contact")
    public String addContact(Model model){

        model.addAttribute("title", "Add Contact");
        model.addAttribute("contact", new Contact());
        return "add_Contact";
    }

    @InitBinder
    public void initBinder(WebDataBinder binder){
        binder.setDisallowedFields("image");
        // binder.setDisallowedFields("image-update");
    }

    @PostMapping("/process-contact")
    public String processContact(@Valid @ModelAttribute("contact") Contact contact, BindingResult result, @RequestParam("image") MultipartFile file, Principal principal, Model model){
       try {
            if(result.hasErrors()){
                model.addAttribute("contact", contact);
                return "add_Contact";
            }

            String name = principal.getName();
            User user = this.userRepository.getUserByUserName(name);
            //processing and uplaoding file
            if(file.isEmpty()){
                contact.setImage("default-contact-image.png");
            }else{
                //upload the file to folder and upload the name in database
                contact.setImage(file.getOriginalFilename());
                File saveFile = new ClassPathResource("static/image/contact-images").getFile();
                path = Paths.get(saveFile.getAbsolutePath() + File.separator + file.getOriginalFilename());
                Files.copy(file.getInputStream(), path , StandardCopyOption.REPLACE_EXISTING);
            }

            contact.setUser(user);
            user.getContacts().add(contact);
            this.userRepository.save(user);
            System.out.println("Saved");
            model.addAttribute("contact", new Contact());
            // session.setAttribute("message", new Message("CONTACT SAVED", "success"));
            return "redirect:/user/view-contacts/0";
            // return "add_Contact";
        } catch (Exception e) {
            // session.setAttribute("message", new Message("Something Went Wrong", "danger"));
            System.out.println("Error: " + e.getMessage());
            return "add_Contact";
        }        
    }

    //show contacts
    @GetMapping("/view-contacts/{page}")
    public String showContacts(@PathVariable("page") Integer page, Model model, Principal principal){
        model.addAttribute("title", "View Contacts");
        String username = principal.getName();
        User user = this.userRepository.getUserByUserName(username);

        Pageable pageable = PageRequest.of(page, 5);
        Page<Contact> contactList = this.contactRepository.findContactByUser(user.getId(),pageable);
        model.addAttribute("contacts", contactList);
        model.addAttribute("currentPage", page);
        if(contactList.getTotalPages() == 0){
            model.addAttribute("totalPages", 1);
        }else{
            model.addAttribute("totalPages", contactList.getTotalPages());
        }
       
        return "view-contacts";
    }

    //showing particluar contact details

    @GetMapping("/contact/{cId}")
    public String showContactDetails(@PathVariable("cId") Integer cId, Model model, Principal principal){
        String username = principal.getName();
        User user = this.userRepository.getUserByUserName(username);
        Optional<Contact> optionalContact = this.contactRepository.findById(cId);
        Contact contact;
        if(optionalContact.isPresent()){
            contact = optionalContact.get();
        }else{
            return "normal/error-detail";
        }
        
        if(user.getId() == contact.getUser().getId()){
            model.addAttribute("contact", contact);
        }else{
            return "normal/error-detail";
        }
        model.addAttribute("title", "Show contact details");       
        return "normal/contact-details";
    }

    //opening user details for update
    @GetMapping("/update-contact/{cId}")
    public String updateContactDetails(@PathVariable("cId") Integer cId, Model model, Principal principal){
        String username = principal.getName();
        User user = this.userRepository.getUserByUserName(username);
        Optional<Contact> optionalContact = this.contactRepository.findById(cId);
        Contact contact;
        if(optionalContact.isPresent()){
            contact = optionalContact.get();
        }else{
            return "normal/error-detail";
        }
        
        if(user.getId() == contact.getUser().getId()){
            model.addAttribute("contact", contact);
        }else{
            return "normal/error-detail";
        }
        model.addAttribute("title", "Update Contact Details");        
        return "normal/update-contact";
    }

    //updating user details handler
    @PostMapping("/process-update")
    public String processUpdate(@Valid @ModelAttribute("contact") Contact contact, BindingResult result, @RequestParam("image-update") MultipartFile file, Principal principal, Model model){
        try {
            if(result.hasErrors()){
                model.addAttribute("contact", contact);
                return "normal/update-Contact";
            }
            Contact oldContactDetails = this.contactRepository.findById(contact.getcId()).get();
            if(!file.isEmpty()){
                // delete image
                File deleteFile = new ClassPathResource("static/image/contact-images").getFile();
                File file1 = new File(deleteFile, oldContactDetails.getImage());
                file1.delete();

                //upload new image
                File saveFile = new ClassPathResource("static/image/contact-images").getFile();
                path = Paths.get(saveFile.getAbsolutePath() + File.separator + file.getOriginalFilename());
                Files.copy(file.getInputStream(), path , StandardCopyOption.REPLACE_EXISTING);
                contact.setImage(file.getOriginalFilename());
            }else{
                contact.setImage(oldContactDetails.getImage());
            }
            int cId = contact.getcId();
            String name = principal.getName();
            User user = this.userRepository.getUserByUserName(name);
            
            contact.setUser(user);
            this.contactRepository.save(contact);
            System.out.println("Updated");
            model.addAttribute("title", "Update Contact details");
            return "redirect:/user/contact/"+cId;
        } catch (Exception e) {
           
            System.out.println("Error: " + e.getMessage());
            return "normal/update-contact";
        }        
    }


    //delete specific user using ciD
    @GetMapping("/delete/{cId}")
    public String deleteContactDetails(@PathVariable("cId") Integer cId, Model model, Principal principal){
        String username = principal.getName();
        User user = this.userRepository.getUserByUserName(username);
        Optional<Contact> optionalContact = this.contactRepository.findById(cId);
        Contact contact;
        if(optionalContact.isPresent()){
            contact = optionalContact.get();
        }else{
            return "normal/error-detail";
        }
        
        if(user.getId() == contact.getUser().getId()){
            String file = contact.getImage();   
            this.contactRepository.delete(contact);
            if(!file.equalsIgnoreCase("default-contact-image.png")){
                try {
                    File getFile = new ClassPathResource("static/image/contact-images").getFile();
                    path = Paths.get(getFile.getAbsolutePath() + File.separator + file);
                    Files.deleteIfExists(path);
                } catch (Exception e) {
                 // exception 
                } 
            }    
        }else{
            return "normal/error-detail";
        }          
        return "redirect:/user/view-contacts/0";   
    }

    //deleting user after coming to update page
    @GetMapping("/delete-1/{cId}")
    public String deleteContactDetailsAfterUpdPage(@PathVariable("cId") Integer cId, Model model, Principal principal){
        String username = principal.getName();
        User user = this.userRepository.getUserByUserName(username);
        Optional<Contact> optionalContact = this.contactRepository.findById(cId);
        Contact contact;
        if(optionalContact.isPresent()){
            contact = optionalContact.get();
        }else{
            return "normal/error-detail";
        }

        if(user.getId() == contact.getUser().getId()){
            this.contactRepository.delete(contact);
        }else{
            return "normal/error-detail";
        }   
               
        return "redirect:/user/view-contacts/0";
       
    }

    //your-profile page
    @GetMapping("/user-profile")
    public String yourProfile(Model model){
        model.addAttribute("title", "Your Profile");
        return "normal/your-profile";
    }

    //showing udpate user page
    @GetMapping("/user-profile/update")
    public String showUserDetailsToUpdate(Model model){
        model.addAttribute("title", "User Update");
        return "normal/user-update";
    }

    @PostMapping("/process-update-user")
    public String processUpdateUser(@Valid @ModelAttribute("user") User user, BindingResult result, Principal principal, Model model){
        try {
            if(result.hasErrors()){
                model.addAttribute("user", user);
                return "normal/user-update";
            }
            // String username = principal.getName();
            // User user1 = this.userRepository.getUserByUserName(username);
            
            this.userRepository.save(user);

            System.out.println("Updated");
            
            return "redirect:/user/user-profile";
        } catch (Exception e) {
           
            System.out.println("Error: " + e.getMessage());
            return "normal/update-contact";
        }        
    }

    @GetMapping("/settings")
    public String userSetttings(Model model){
        model.addAttribute("title", "Settings");
        return "normal/settings";
    }

    @GetMapping("/settings/changePassword")
    public String showchangePassword(Model model){
        model.addAttribute("title", "Change Password");

        return "normal/change-password";
    }

    @PostMapping("/process-changePassword")
    public String changePassword(@Valid @ModelAttribute("user") User user, BindingResult result, @RequestParam("cpassword") String confirmpassword, Principal principal, Model model){
        if(result.hasErrors()){
            model.addAttribute("user", user);
                return "normal/change-password";
        }
        // String name = principal.getName();
        // User user1 =  this.userRepository.getUserByUserName(name);
        System.out.println(user.getPassword());
        System.out.println(confirmpassword);
        String password = user.getPassword();
        if(password.equals(confirmpassword) && password != " " && confirmpassword != " " ){
            user.setPassword(passwordEncoder.encode(password));
            this.userRepository.save(user);
        }else{
            return "normal/error-detail";
        }
        return "redirect:/logout";
    }
}
